const commando = require('discord.js-commando');

class BallCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: '8ball',
  group: 'random',
  memberName:'8ball',
  description: 'Answers a yes or no question.'   
  });
 }
  async run(message, args){
var roll = Math.floor(Math.random() * 4) + 1;
if (roll == [1])
{
message.say("Yes");
}
    else
    if (roll == [3])
{
 message.say("no");
}
else 
if (roll == [2])
{
    message.say("Ask again.")
}
else 
if (roll ==[4])
{
    message.say("Uncertain")
}
  }
  }
module.exports = BallCommand;