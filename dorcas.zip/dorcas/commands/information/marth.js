const commando = require('discord.js-commando');

class MarthCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: 'marth',
  group: 'information',
  memberName:'marth',
  description: 'Spouts info about Marth'   
  });
 }
 async run(message, args){
message.say('Altean Prince!');
 }
}

module.exports = MarthCommand;