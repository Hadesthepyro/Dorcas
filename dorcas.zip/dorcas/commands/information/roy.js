const commando = require('discord.js-commando');

class RoyCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: 'roy',
  group: 'information',
  memberName:'roy',
  description: 'Spouts info about Roy'   
  });
 }
 async run(message, args){
message.say('Young Lion!');
 }
}

module.exports = RoyCommand;