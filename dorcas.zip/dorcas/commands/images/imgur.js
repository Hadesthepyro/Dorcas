const commando = require('discord.js-commando');

class ImgurCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: 'imgur',
  group: 'images',
  memberName:'images',
  description: 'command under construction'   
  });
 }
 async run(message, args){
message.reply('WHAT PART OF UNDER CONSTRUCTION DONT YOU UNDERSTAND???');
 }
}

module.exports = ImgurCommand;