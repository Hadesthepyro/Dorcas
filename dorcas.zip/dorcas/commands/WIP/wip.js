const commando = require('discord.js-commando');

class WipCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: 'wip',
  group: 'wip',
  memberName:'wip',
  description: 'States what the bot creator has planned.'   
  });
 }
 async run(message, args){
message.reply('Music, Image grabber, Advantage Summary, Relationship system, What happened to Dorcas?, Combat,and Wiki grabber[List is in order of most important to least but may not happen in that order]');
 }
}

module.exports = WipCommand;