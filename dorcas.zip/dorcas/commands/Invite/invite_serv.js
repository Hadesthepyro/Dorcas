const commando = require('discord.js-commando');

class InviteServCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: 'inviteserv',
  group: 'invite',
  memberName:'inviteserv',
  description: 'Gives invite link for you to join main server'   
  });
 }
 async run(message, args){
message.reply("Main server I'm in if you need help is https://discord.gg/qzUnEfK");
 }
}

module.exports = InviteServCommand;
