const commando = require('discord.js-commando');

class InviteCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: 'invite',
  group: 'invite',
  memberName:'invite',
  description: 'Gives invite link for Dorcas to join you'   
  });
 }
 async run(message, args){
message.reply("Even though I'm currently under development and am private here https://discordapp.com/oauth2/authorize?permissions=1543504009&scope=bot&client_id=310899652507598849");
 }
}

module.exports = InviteCommand;