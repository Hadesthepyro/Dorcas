const commando = require('discord.js-commando');

class RollCommand extends commando.Command {
 constructor(client) {
  super(client, {
  name: 'play',
  group: 'music',
  memberName:'play',
  description: 'Command under construct'   
  });
 }
 async run(message, args){
var roll = Math.floor(Math.random() * 6) + 1;
message.say("Under Construct");
 }
}

module.exports = RollCommand;