const Discord = require('discord.js');
const commando = require('discord.js-commando')
const dorcas = new commando.Client({
    owner: '(id here)',
    commandPrefix: ')',
});

dorcas.registry.registerGroup('music', 'Music');
dorcas.registry.registerGroup('random', 'Random');
dorcas.registry.registerGroup('information', 'Information');
dorcas.registry.registerGroup('wip', 'WIP');
dorcas.registry.registerGroup('images', 'Images');
dorcas.registry.registerGroup('invite', 'Invite');
dorcas.registry.registerDefaults();
dorcas.registry.registerCommandsIn(__dirname + "/commands");

dorcas.login('(token here)');
